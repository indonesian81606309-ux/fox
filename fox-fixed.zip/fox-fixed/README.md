# 🦊 3+ Fox Market

Platform jual-beli item game online dengan fitur lengkap: produk, order, chat real-time, giveaway, redeem code, dan panel admin.

## 🗂️ Struktur Project

```
fox-main/
├── Express/backend/     ← Backend utama (Express.js + Socket.io)
└── frontend/            ← Frontend (Next.js 14 + Tailwind CSS)
```

## ⚙️ Setup Backend

```bash
cd Express/backend
npm install
cp .env.example .env   # isi dengan konfigurasi kamu
node server.js
```

### Environment Variables (`.env`)
| Variable | Keterangan |
|---|---|
| `PORT` | Port server (default: 5000) |
| `MONGO_URI` | MongoDB connection string |
| `JWT_SECRET` | Secret key untuk JWT |
| `CLOUDINARY_CLOUD_NAME` | Cloudinary cloud name |
| `CLOUDINARY_API_KEY` | Cloudinary API key |
| `CLOUDINARY_API_SECRET` | Cloudinary API secret |
| `FRONTEND_URL` | URL frontend (untuk CORS) |

## 🎨 Setup Frontend

```bash
cd frontend
npm install
cp .env.example .env.local   # isi URL backend
npm run dev
```

### Environment Variables (`.env.local`)
| Variable | Default |
|---|---|
| `NEXT_PUBLIC_API_URL` | `http://localhost:5000/api` |
| `NEXT_PUBLIC_SOCKET_URL` | `http://localhost:5000` |

## 🔑 Roles & Akses

| Role | Akses |
|---|---|
| `user` | Beli produk, chat admin, redeem code, giveaway, review, laporan |
| `admin2/3/4` | Kelola produk, terima/tolak order & penawaran |
| `superadmin` | Semua akses admin + statistik, redeem code, payment method, giveaway, jasa |

## 📡 API Endpoints

### Auth
- `POST /api/auth/register` — Daftar akun
- `POST /api/auth/login` — Login
- `GET /api/auth/me` — Info user (butuh token)

### Products
- `GET /api/products` — Daftar produk (query: `game`, `type`, `search`)
- `GET /api/products/:id` — Detail produk
- `POST /api/products` — Tambah produk (admin)
- `PUT /api/products/:id` — Edit produk (admin)
- `DELETE /api/products/:id` — Hapus produk (admin)

### Orders
- `POST /api/orders` — Buat pesanan
- `GET /api/orders/myorders` — Pesanan saya
- `POST /api/orders/:id/proof` — Upload bukti bayar
- `GET /api/orders/admin/all` — Semua pesanan (admin)
- `PUT /api/orders/admin/:id/accept` — Terima pesanan (admin)
- `PUT /api/orders/admin/:id/reject` — Tolak pesanan (admin)

### Chat
- `GET /api/chats/conversation/:userId` — Riwayat chat
- `POST /api/chats/send` — Kirim pesan (dengan file)
- `GET /api/users/admins` — Daftar admin untuk chat

### Redeem
- `POST /api/redeem/check` — Cek kode
- `POST /api/redeem/use` — Gunakan kode
- `POST /api/redeem` — Buat kode (superadmin)
- `GET /api/redeem` — Daftar kode (superadmin)

## 🐛 Bug yang Sudah Diperbaiki

1. **Redeem query** — `$lt: '$maxUses'` (string) → `$expr: { $lt: ['$usedCount', '$maxUses'] }`
2. **Server.js imports** — Path route salah (dari `./routes/auth.js` → `./routes/app/api/auth.js`)
3. **Chat /users/admins** — Route `/users` tidak ada → dibuat `users.js` route baru
4. **protect middleware** — Double response bug saat token invalid → ditambah `return`
5. **Product.js filename** — Ada spasi di nama file → dibersihkan
6. **ParticleBackground** — File kosong → diimplementasi dengan Canvas animation
7. **CORS** — `origin: '*'` → restricted ke `FRONTEND_URL` env
8. **Navbar prop** — `toggleSidebar` → `onMenuClick` (sesuai layout)
9. **Chat socket** — Duplicate message bug → ditambah dedup check
10. **Register** — Auto-login setelah register dihapus (keamanan)

## 📄 Halaman Baru yang Ditambahkan

- `/dashboard/offers` — Form & riwayat penawaran item ke admin
- `/dashboard/redeem` — Tukar kode redeem
- `/dashboard/services` — Katalog jasa admin
- `/dashboard/events` — Event & giveaway aktif
- `/dashboard/reviews` — Ulasan pelanggan dengan rating bintang
