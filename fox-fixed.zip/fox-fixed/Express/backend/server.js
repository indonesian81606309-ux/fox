import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import http from 'http';
import { Server } from 'socket.io';
import connectDB from './config/db.js';
import authRoutes from './routes/app/api/auth.js';
import productRoutes from './routes/app/api/products.js';
import orderRoutes from './routes/app/api/orders.js';
import offerRoutes from './routes/app/api/offers.js';
import chatRoutes from './routes/app/api/chats.js';
import redeemRoutes from './routes/app/api/redeem.js';
import giveawayRoutes from './routes/app/api/giveaway.js';
import reportRoutes from './routes/app/api/reports.js';
import paymentRoutes from './routes/app/api/payments.js';
import serviceRoutes from './routes/app/api/services.js';
import reviewRoutes from './routes/app/api/reviews.js';
import adminRoutes from './routes/app/api/admin.js';
import userRoutes from './routes/app/api/users.js';
import Chat from './models/Chat.js';

dotenv.config();
connectDB();

const app = express();

const allowedOrigins = process.env.FRONTEND_URL
  ? [process.env.FRONTEND_URL]
  : ['http://localhost:3000'];

app.use(cors({
  origin: allowedOrigins,
  credentials: true,
}));
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/offers', offerRoutes);
app.use('/api/chats', chatRoutes);
app.use('/api/redeem', redeemRoutes);
app.use('/api/giveaway', giveawayRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/services', serviceRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/users', userRoutes);

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: allowedOrigins, credentials: true },
});

io.on('connection', (socket) => {
  const userId = socket.handshake.auth.userId;
  if (userId) socket.join(userId);

  socket.on('sendMessage', async (data) => {
    const { senderId, receiverId, message, fileUrl, fileType } = data;
    try {
      const chat = await Chat.create({ sender: senderId, receiver: receiverId, message, fileUrl, fileType });
      io.to(receiverId).emit('newMessage', chat);
      io.to(senderId).emit('newMessage', chat);
    } catch (err) {
      console.error('Socket sendMessage error:', err);
    }
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
