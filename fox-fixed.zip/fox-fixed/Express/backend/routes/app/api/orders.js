import express from 'express';
import Order from '../models/Order.js';
import Product from '../models/Product.js';
import RedeemCode from '../models/RedeemCode.js';
import { protect, adminOnly } from '../middleware/auth.js';
import { upload } from '../middleware/upload.js';
const router = express.Router();

// Create order
router.post('/', protect, async (req, res) => {
  try {
    const { productId, quantity, paymentMethod, redeemCode } = req.body;
    const product = await Product.findById(productId);
    if (!product) return res.status(404).json({ message: 'Produk tidak ditemukan' });
    if (product.stock < quantity) return res.status(400).json({ message: 'Stok tidak mencukupi' });

    let discount = 0;
    let giftMessage = '';
    if (redeemCode) {
      const code = await RedeemCode.findOne({
        code: redeemCode,
        expiresAt: { $gt: new Date() },
        $expr: { $lt: ['$usedCount', '$maxUses'] },
      });
      if (code) {
        discount = code.discount;
        giftMessage = code.gift || '';
        code.usedCount += 1;
        await code.save();
      }
    }

    const tax = 5000;
    const total = (product.price * quantity) + tax - discount;
    const uniqueCode = Math.floor(100000 + Math.random() * 900000).toString();

    const order = await Order.create({
      user: req.user._id,
      product: productId,
      quantity,
      totalPrice: total,
      discount,
      tax,
      paymentMethod,
      uniqueCode,
      giftMessage,
      status: 'pending',
    });

    res.status(201).json(order);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Get my orders
router.get('/myorders', protect, async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user._id }).populate('product').sort('-createdAt');
    res.json(orders);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Upload payment proof
router.post('/:id/proof', protect, upload.single('proof'), async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'Order tidak ditemukan' });
    if (order.user.toString() !== req.user._id.toString())
      return res.status(403).json({ message: 'Forbidden' });
    if (!req.file) return res.status(400).json({ message: 'File bukti wajib diupload' });
    order.paymentProof = req.file.path;
    order.status = 'paid';
    await order.save();
    res.json(order);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Admin: get all orders
router.get('/admin/all', protect, adminOnly, async (req, res) => {
  try {
    const orders = await Order.find().populate('user', 'username fullName').populate('product').sort('-createdAt');
    res.json(orders);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Admin: accept order
router.put('/admin/:id/accept', protect, adminOnly, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id).populate('product');
    if (!order) return res.status(404).json({ message: 'Order tidak ditemukan' });
    if (order.status !== 'paid') return res.status(400).json({ message: 'Order belum dibayar' });
    const product = order.product;
    if (product.stock < order.quantity) return res.status(400).json({ message: 'Stok tidak cukup' });
    product.stock -= order.quantity;
    await product.save();
    order.status = 'accepted';
    await order.save();
    res.json(order);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Admin: reject order
router.put('/admin/:id/reject', protect, adminOnly, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'Order tidak ditemukan' });
    order.status = 'rejected';
    await order.save();
    res.json(order);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
