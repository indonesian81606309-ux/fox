import express from 'express';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import { protect } from '../middleware/auth.js';
const router = express.Router();

router.post('/register', async (req, res) => {
  try {
    const { username, fullName, password } = req.body;
    if (!username || !fullName || !password)
      return res.status(400).json({ message: 'Semua field wajib diisi' });
    if (password.length < 6)
      return res.status(400).json({ message: 'Password minimal 6 karakter' });
    const userExists = await User.findOne({ username });
    if (userExists) return res.status(400).json({ message: 'Username sudah digunakan' });
    const user = await User.create({ username, fullName, password });
    res.status(201).json({ message: 'Pendaftaran berhasil, silakan login' });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password)
      return res.status(400).json({ message: 'Username dan password wajib diisi' });
    const user = await User.findOne({ username });
    if (user && (await user.matchPassword(password))) {
      const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '30d' });
      res.json({ token, user: { id: user._id, username, fullName: user.fullName, role: user.role } });
    } else {
      res.status(401).json({ message: 'Username atau password salah' });
    }
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/me', protect, async (req, res) => {
  res.json({ id: req.user._id, username: req.user.username, fullName: req.user.fullName, role: req.user.role });
});

export default router;
