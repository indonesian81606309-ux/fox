import express from 'express';
import RedeemCode from '../models/RedeemCode.js';
import { protect, superAdminOnly } from '../middleware/auth.js';
const router = express.Router();

// Helper: cek apakah kode valid
const findValidCode = (code) =>
  RedeemCode.findOne({
    code,
    expiresAt: { $gt: new Date() },
    $expr: { $lt: ['$usedCount', '$maxUses'] },
  });

router.post('/check', protect, async (req, res) => {
  try {
    const { code } = req.body;
    const redeem = await findValidCode(code);
    if (!redeem) return res.status(400).json({ message: 'Kode tidak valid atau sudah habis' });
    res.json({ discount: redeem.discount, gift: redeem.gift });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.post('/use', protect, async (req, res) => {
  try {
    const { code } = req.body;
    const redeem = await findValidCode(code);
    if (!redeem) return res.status(400).json({ message: 'Kode tidak valid atau sudah habis' });
    redeem.usedCount += 1;
    await redeem.save();
    res.json({ success: true, discount: redeem.discount, gift: redeem.gift });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Admin routes
router.post('/', protect, superAdminOnly, async (req, res) => {
  try {
    const { code, discount, gift, maxUses, expiresAt } = req.body;
    const newCode = await RedeemCode.create({ code, discount, gift, maxUses, expiresAt, createdBy: req.user._id });
    res.status(201).json(newCode);
  } catch (err) {
    if (err.code === 11000) return res.status(400).json({ message: 'Kode sudah ada' });
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/', protect, superAdminOnly, async (req, res) => {
  try {
    const codes = await RedeemCode.find().populate('createdBy', 'username');
    res.json(codes);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.delete('/:id', protect, superAdminOnly, async (req, res) => {
  try {
    await RedeemCode.findByIdAndDelete(req.params.id);
    res.json({ message: 'Kode dihapus' });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
