import express from 'express';
import User from '../models/User.js';
import { protect } from '../middleware/auth.js';
const router = express.Router();

// Get list of admins (for chat feature)
router.get('/admins', protect, async (req, res) => {
  try {
    const admins = await User.find({ role: { $ne: 'user' } }).select('_id username fullName role');
    res.json(admins);
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get user profile
router.get('/me', protect, async (req, res) => {
  res.json(req.user);
});

export default router;
