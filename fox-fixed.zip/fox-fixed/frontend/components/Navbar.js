'use client';
import { FaBars, FaUser } from 'react-icons/fa';
import { useAuth } from '@/context/AuthContext';

export default function Navbar({ onMenuClick }) {
  const { user, logout } = useAuth();
  return (
    <div className="sticky top-0 bg-black/80 backdrop-blur-md border-b border-blue-500/30 z-30 px-4 py-3 flex justify-between items-center">
      <button onClick={onMenuClick} className="text-2xl text-blue-400 md:hidden"><FaBars /></button>
      <div className="hidden md:block text-blue-400 font-semibold">3+ Fox Market</div>
      <div className="flex items-center gap-4">
        <div className="relative group">
          <button className="flex items-center gap-2 text-sm hover:text-blue-400 transition-colors">
            <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center text-xs font-bold">
              {user?.username?.[0]?.toUpperCase()}
            </div>
            <span className="hidden sm:inline">{user?.username}</span>
          </button>
          <div className="absolute right-0 mt-2 w-36 bg-black/95 border border-blue-500/50 rounded-xl shadow-xl hidden group-hover:block">
            <div className="px-4 py-2 border-b border-blue-500/20">
              <p className="text-xs text-gray-400">Login sebagai</p>
              <p className="text-sm font-semibold text-blue-400">{user?.role}</p>
            </div>
            <button onClick={logout} className="block w-full text-left px-4 py-2 hover:bg-red-500/20 text-red-400 text-sm rounded-b-xl">
              Logout
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
