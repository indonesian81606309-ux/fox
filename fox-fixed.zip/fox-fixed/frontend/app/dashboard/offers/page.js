'use client';
import { useEffect, useState } from 'react';
import axios from '@/lib/axios';
import { useAuth } from '@/context/AuthContext';
import toast from 'react-hot-toast';
import Loading from '@/components/Loading';

export default function OffersPage() {
  const { user } = useAuth();
  const [offers, setOffers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ itemName: '', game: '', description: '' });
  const [imageFile, setImageFile] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const fetchOffers = async () => {
    try {
      const res = await axios.get('/offers/myoffers');
      setOffers(res.data);
    } catch {
      toast.error('Gagal memuat penawaran');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchOffers(); }, []);

  const handleSubmit = async () => {
    if (!form.itemName || !form.game) return toast.error('Nama item dan game wajib diisi');
    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('itemName', form.itemName);
      formData.append('game', form.game);
      formData.append('description', form.description);
      if (imageFile) formData.append('image', imageFile);
      await axios.post('/offers', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success('Penawaran terkirim! Admin akan merespons segera.');
      setForm({ itemName: '', game: '', description: '' });
      setImageFile(null);
      fetchOffers();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Gagal mengirim penawaran');
    } finally {
      setSubmitting(false);
    }
  };

  const statusColor = (s) => s === 'accepted' ? 'text-green-400' : s === 'rejected' ? 'text-red-400' : 'text-yellow-400';

  if (loading) return <Loading />;

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-blue-400">Tawarkan Item ke Admin</h1>

      {/* Form */}
      <div className="glass p-6 rounded-2xl border border-blue-500/30 space-y-4">
        <h2 className="text-xl font-semibold">Buat Penawaran Baru</h2>
        <input
          type="text" placeholder="Nama Item (contoh: Akun ML Diamond)"
          className="w-full p-3 bg-black/50 border border-blue-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          value={form.itemName} onChange={e => setForm({ ...form, itemName: e.target.value })}
        />
        <input
          type="text" placeholder="Game (contoh: Mobile Legends)"
          className="w-full p-3 bg-black/50 border border-blue-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          value={form.game} onChange={e => setForm({ ...form, game: e.target.value })}
        />
        <textarea
          placeholder="Deskripsi item (rank, skin, dll)..."
          rows={3}
          className="w-full p-3 bg-black/50 border border-blue-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
          value={form.description} onChange={e => setForm({ ...form, description: e.target.value })}
        />
        <div>
          <label className="text-sm text-gray-400 mb-1 block">Screenshot / Foto Bukti (opsional)</label>
          <input type="file" accept="image/*" onChange={e => setImageFile(e.target.files[0])}
            className="text-sm text-gray-300" />
        </div>
        <button
          onClick={handleSubmit} disabled={submitting}
          className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-50 py-3 rounded-lg font-bold transition-all"
        >
          {submitting ? 'Mengirim...' : 'Kirim Penawaran'}
        </button>
      </div>

      {/* List */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Penawaran Saya</h2>
        {offers.length === 0 ? (
          <p className="text-gray-500 text-center py-8">Belum ada penawaran</p>
        ) : (
          <div className="space-y-3">
            {offers.map(offer => (
              <div key={offer._id} className="glass p-4 rounded-xl border border-blue-500/20">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-semibold text-lg">{offer.itemName}</p>
                    <p className="text-sm text-gray-400">{offer.game}</p>
                    {offer.description && <p className="text-sm text-gray-300 mt-1">{offer.description}</p>}
                  </div>
                  <span className={`text-sm font-semibold ${statusColor(offer.status)}`}>
                    {offer.status === 'pending' ? '⏳ Menunggu' : offer.status === 'accepted' ? '✅ Diterima' : '❌ Ditolak'}
                  </span>
                </div>
                {offer.imageUrl && <img src={offer.imageUrl} alt="bukti" className="mt-3 h-32 rounded-lg object-cover" />}
                {offer.status === 'accepted' && (
                  <p className="mt-2 text-green-400 text-sm">Admin telah menerima penawaranmu. Cek Chat Admin!</p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
