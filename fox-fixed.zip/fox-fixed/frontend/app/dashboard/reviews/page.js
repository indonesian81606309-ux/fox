'use client';
import { useEffect, useState } from 'react';
import axios from '@/lib/axios';
import { useAuth } from '@/context/AuthContext';
import toast from 'react-hot-toast';
import Loading from '@/components/Loading';

function StarRating({ value, onChange }) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map(star => (
        <button
          key={star}
          onClick={() => onChange && onChange(star)}
          className={`text-2xl transition-transform hover:scale-110 ${star <= value ? 'text-yellow-400' : 'text-gray-600'}`}
        >
          ★
        </button>
      ))}
    </div>
  );
}

export default function ReviewsPage() {
  const { user } = useAuth();
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const fetchReviews = async () => {
    try {
      const res = await axios.get('/reviews');
      setReviews(res.data);
    } catch {
      toast.error('Gagal memuat ulasan');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchReviews(); }, []);

  const handleSubmit = async () => {
    if (!comment.trim()) return toast.error('Tulis ulasan terlebih dahulu');
    setSubmitting(true);
    try {
      await axios.post('/reviews', { rating, comment });
      toast.success('Ulasan berhasil dikirim!');
      setComment('');
      setRating(5);
      fetchReviews();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Gagal mengirim ulasan');
    } finally {
      setSubmitting(false);
    }
  };

  const avgRating = reviews.length
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : 0;

  const timeAgo = (date) => {
    const diff = Date.now() - new Date(date);
    const days = Math.floor(diff / 86400000);
    if (days === 0) return 'Hari ini';
    if (days === 1) return 'Kemarin';
    return `${days} hari lalu`;
  };

  if (loading) return <Loading />;

  return (
    <div className="space-y-8">
      <div className="flex items-end gap-6">
        <div>
          <h1 className="text-3xl font-bold text-blue-400">Ulasan Pelanggan</h1>
          <p className="text-gray-400 mt-1">Ceritakan pengalamanmu dengan 3+ Fox Market</p>
        </div>
        {reviews.length > 0 && (
          <div className="glass px-4 py-2 rounded-xl border border-yellow-500/30 text-center">
            <p className="text-3xl font-bold text-yellow-400">{avgRating}</p>
            <StarRating value={Math.round(avgRating)} />
            <p className="text-xs text-gray-400">{reviews.length} ulasan</p>
          </div>
        )}
      </div>

      {/* Form */}
      <div className="glass p-6 rounded-2xl border border-blue-500/30 space-y-4">
        <h2 className="text-xl font-semibold">Tulis Ulasanmu</h2>
        <div>
          <p className="text-sm text-gray-400 mb-2">Rating</p>
          <StarRating value={rating} onChange={setRating} />
        </div>
        <textarea
          placeholder="Ceritakan pengalamanmu berbelanja di 3+ Fox Market..."
          rows={4}
          className="w-full p-3 bg-black/50 border border-blue-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 resize-none"
          value={comment}
          onChange={e => setComment(e.target.value)}
        />
        <button
          onClick={handleSubmit} disabled={submitting}
          className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 px-6 py-3 rounded-lg font-bold transition-all"
        >
          {submitting ? 'Mengirim...' : '⭐ Kirim Ulasan'}
        </button>
      </div>

      {/* Reviews List */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Semua Ulasan</h2>
        {reviews.length === 0 ? (
          <p className="text-gray-500 text-center py-8">Belum ada ulasan. Jadilah yang pertama!</p>
        ) : (
          reviews.map(review => (
            <div key={review._id} className="glass p-4 rounded-xl border border-blue-500/20">
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-sm font-bold">
                      {review.user?.username?.[0]?.toUpperCase() || '?'}
                    </div>
                    <span className="font-semibold">{review.user?.fullName || review.user?.username}</span>
                  </div>
                  <StarRating value={review.rating} />
                </div>
                <span className="text-xs text-gray-500">{timeAgo(review.createdAt)}</span>
              </div>
              <p className="mt-3 text-gray-300 leading-relaxed">{review.comment}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
