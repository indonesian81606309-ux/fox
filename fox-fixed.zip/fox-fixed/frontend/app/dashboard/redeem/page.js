'use client';
import { useState } from 'react';
import axios from '@/lib/axios';
import toast from 'react-hot-toast';

export default function RedeemPage() {
  const [code, setCode] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleCheck = async () => {
    if (!code.trim()) return toast.error('Masukkan kode redeem');
    setLoading(true);
    setResult(null);
    try {
      const res = await axios.post('/redeem/check', { code: code.trim().toUpperCase() });
      setResult(res.data);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Kode tidak valid');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-8">
      <h1 className="text-3xl font-bold text-blue-400">Tukar Kode Redeem</h1>

      <div className="glass p-6 rounded-2xl border border-blue-500/30 space-y-4">
        <p className="text-gray-400 text-sm">Masukkan kode yang kamu dapatkan dari admin atau event giveaway.</p>
        <input
          type="text"
          placeholder="Contoh: FOX2024"
          className="w-full p-3 bg-black/50 border border-blue-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 uppercase tracking-widest text-center text-lg font-bold"
          value={code}
          onChange={e => setCode(e.target.value.toUpperCase())}
          onKeyDown={e => e.key === 'Enter' && handleCheck()}
        />
        <button
          onClick={handleCheck} disabled={loading}
          className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-50 py-3 rounded-lg font-bold transition-all"
        >
          {loading ? 'Mengecek...' : '🎁 Cek Kode'}
        </button>
      </div>

      {result && (
        <div className="glass p-6 rounded-2xl border border-green-500/50 space-y-3 animate-pulse-once">
          <h2 className="text-xl font-bold text-green-400">🎉 Kode Valid!</h2>
          {result.discount > 0 && (
            <div className="flex items-center gap-3">
              <span className="text-2xl">💰</span>
              <div>
                <p className="text-sm text-gray-400">Diskon</p>
                <p className="text-2xl font-bold text-green-400">Rp {result.discount.toLocaleString()}</p>
              </div>
            </div>
          )}
          {result.gift && (
            <div className="flex items-center gap-3">
              <span className="text-2xl">🎁</span>
              <div>
                <p className="text-sm text-gray-400">Hadiah</p>
                <p className="text-lg font-semibold text-yellow-300">{result.gift}</p>
              </div>
            </div>
          )}
          <p className="text-sm text-gray-400 mt-2">Kode ini akan otomatis diterapkan saat checkout pembelian.</p>
        </div>
      )}

      <div className="glass p-4 rounded-xl border border-blue-500/20">
        <h3 className="font-semibold mb-2 text-blue-300">📌 Info Redeem</h3>
        <ul className="text-sm text-gray-400 space-y-1 list-disc list-inside">
          <li>Kode redeem bisa berupa diskon harga atau hadiah item</li>
          <li>Setiap kode memiliki batas penggunaan</li>
          <li>Kode tidak bisa digunakan setelah expired</li>
          <li>Dapatkan kode dari event giveaway atau promo admin</li>
        </ul>
      </div>
    </div>
  );
}
