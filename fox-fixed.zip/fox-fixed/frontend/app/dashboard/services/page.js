'use client';
import { useEffect, useState } from 'react';
import axios from '@/lib/axios';
import { useAuth } from '@/context/AuthContext';
import toast from 'react-hot-toast';
import Loading from '@/components/Loading';

export default function ServicesPage() {
  const { user } = useAuth();
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('/services')
      .then(res => setServices(res.data))
      .catch(() => toast.error('Gagal memuat jasa'))
      .finally(() => setLoading(false));
  }, []);

  const handleOrder = async (service) => {
    const confirm = window.confirm(`Pesan jasa "${service.name}" seharga Rp ${service.price.toLocaleString()}?`);
    if (!confirm) return;
    toast.success('Permintaan jasa terkirim! Admin akan menghubungimu via Chat.');
  };

  if (loading) return <Loading />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-blue-400">Jasa Admin</h1>
        <p className="text-gray-400 mt-1">Layanan eksklusif dari tim admin 3+ Fox</p>
      </div>

      {services.length === 0 ? (
        <div className="text-center py-16 text-gray-500">
          <p className="text-4xl mb-3">🛠️</p>
          <p>Belum ada jasa yang tersedia saat ini</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {services.map(service => (
            <div key={service._id} className="glass rounded-2xl border border-blue-500/30 p-5 hover:border-blue-400/60 transition-all flex flex-col">
              <div className="flex-1">
                <div className="w-10 h-10 rounded-full bg-blue-600/30 flex items-center justify-center mb-3 text-xl">🎮</div>
                <h3 className="font-bold text-lg">{service.name}</h3>
                {service.description && (
                  <p className="text-sm text-gray-400 mt-1">{service.description}</p>
                )}
              </div>
              <div className="mt-4 flex items-center justify-between">
                <span className="text-xl font-bold text-blue-400">Rp {service.price.toLocaleString()}</span>
                <button
                  onClick={() => handleOrder(service)}
                  className="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-lg text-sm font-semibold transition-all"
                >
                  Pesan
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="glass p-4 rounded-xl border border-yellow-500/20">
        <h3 className="font-semibold mb-2 text-yellow-300">💬 Cara Pesan Jasa</h3>
        <ol className="text-sm text-gray-400 space-y-1 list-decimal list-inside">
          <li>Pilih jasa yang kamu inginkan dan klik "Pesan"</li>
          <li>Admin akan menghubungimu melalui fitur Chat Admin</li>
          <li>Diskusikan detail dan lakukan pembayaran sesuai instruksi admin</li>
          <li>Jasa akan dikerjakan setelah pembayaran dikonfirmasi</li>
        </ol>
      </div>
    </div>
  );
}
