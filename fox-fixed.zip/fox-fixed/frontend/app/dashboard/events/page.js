'use client';
import { useEffect, useState } from 'react';
import axios from '@/lib/axios';
import { useAuth } from '@/context/AuthContext';
import toast from 'react-hot-toast';
import Loading from '@/components/Loading';

export default function EventsPage() {
  const { user } = useAuth();
  const [giveaways, setGiveaways] = useState([]);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState('');

  const fetchGiveaways = async () => {
    try {
      const res = await axios.get('/giveaway');
      setGiveaways(res.data);
    } catch {
      toast.error('Gagal memuat event');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchGiveaways(); }, []);

  const handleJoin = async (id) => {
    setJoining(id);
    try {
      await axios.post(`/giveaway/${id}/join`);
      toast.success('🎉 Berhasil ikut giveaway!');
      fetchGiveaways();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Gagal bergabung');
    } finally {
      setJoining('');
    }
  };

  const timeLeft = (endDate) => {
    const diff = new Date(endDate) - new Date();
    if (diff <= 0) return 'Berakhir';
    const days = Math.floor(diff / 86400000);
    const hours = Math.floor((diff % 86400000) / 3600000);
    return days > 0 ? `${days} hari ${hours} jam lagi` : `${hours} jam lagi`;
  };

  const hasJoined = (giveaway) =>
    giveaway.participants?.some(p => (p._id || p) === user?.id);

  if (loading) return <Loading />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-blue-400">Event & Giveaway</h1>
        <p className="text-gray-400 mt-1">Ikuti giveaway dan menangkan hadiah menarik!</p>
      </div>

      {giveaways.length === 0 ? (
        <div className="text-center py-16 text-gray-500">
          <p className="text-5xl mb-3">🎁</p>
          <p className="text-lg">Tidak ada event aktif saat ini</p>
          <p className="text-sm mt-1">Pantau terus untuk event berikutnya!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {giveaways.map(giveaway => {
            const joined = hasJoined(giveaway);
            return (
              <div key={giveaway._id} className="glass rounded-2xl border border-blue-500/30 overflow-hidden hover:border-blue-400/60 transition-all">
                {giveaway.imageUrl && (
                  <img src={giveaway.imageUrl} alt={giveaway.title} className="w-full h-40 object-cover" />
                )}
                <div className="p-5 space-y-3">
                  <div className="flex justify-between items-start">
                    <h3 className="font-bold text-xl">{giveaway.title}</h3>
                    <span className="text-xs bg-blue-600/30 text-blue-300 px-2 py-1 rounded-full">{timeLeft(giveaway.endDate)}</span>
                  </div>
                  {giveaway.description && <p className="text-sm text-gray-400">{giveaway.description}</p>}
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="bg-black/30 rounded-lg p-2">
                      <p className="text-gray-500">Hadiah</p>
                      <p className="font-semibold text-yellow-300">🏆 {giveaway.prize}</p>
                    </div>
                    <div className="bg-black/30 rounded-lg p-2">
                      <p className="text-gray-500">Pemenang</p>
                      <p className="font-semibold">{giveaway.winnersCount} orang</p>
                    </div>
                    <div className="bg-black/30 rounded-lg p-2">
                      <p className="text-gray-500">Peserta</p>
                      <p className="font-semibold">{giveaway.participants?.length || 0} orang</p>
                    </div>
                    {giveaway.game && (
                      <div className="bg-black/30 rounded-lg p-2">
                        <p className="text-gray-500">Game</p>
                        <p className="font-semibold">{giveaway.game}</p>
                      </div>
                    )}
                  </div>
                  <button
                    onClick={() => handleJoin(giveaway._id)}
                    disabled={joined || joining === giveaway._id}
                    className={`w-full py-3 rounded-lg font-bold transition-all ${joined ? 'bg-green-700/50 text-green-300 cursor-default' : 'bg-blue-600 hover:bg-blue-500 disabled:opacity-50'}`}
                  >
                    {joining === giveaway._id ? 'Mendaftar...' : joined ? '✅ Sudah Ikut' : '🎉 Ikut Giveaway'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
