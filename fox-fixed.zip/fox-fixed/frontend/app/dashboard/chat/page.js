'use client';
import { useEffect, useState, useRef, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import axios from '@/lib/axios';
import { initSocket } from '@/lib/socket';
import toast from 'react-hot-toast';
import Loading from '@/components/Loading';

export default function ChatPage() {
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [admins, setAdmins] = useState([]);
  const [selectedAdmin, setSelectedAdmin] = useState(null);
  const [loadingAdmins, setLoadingAdmins] = useState(true);
  const messagesEndRef = useRef(null);
  const socketRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => { scrollToBottom(); }, [messages]);

  useEffect(() => {
    if (!user) return;
    socketRef.current = initSocket(user.id);
    socketRef.current.on('newMessage', (msg) => {
      setMessages(prev => {
        const isDuplicate = prev.some(m => m._id === msg._id);
        return isDuplicate ? prev : [...prev, msg];
      });
    });

    axios.get('/users/admins')
      .then(res => setAdmins(res.data))
      .catch(() => toast.error('Gagal memuat daftar admin'))
      .finally(() => setLoadingAdmins(false));

    return () => socketRef.current?.disconnect();
  }, [user]);

  useEffect(() => {
    if (!selectedAdmin) return;
    axios.get(`/chats/conversation/${selectedAdmin._id}`)
      .then(res => setMessages(res.data))
      .catch(() => toast.error('Gagal memuat pesan'));
  }, [selectedAdmin]);

  const sendMessage = useCallback(() => {
    if (!newMessage.trim() || !selectedAdmin) return;
    const msgData = { senderId: user.id, receiverId: selectedAdmin._id, message: newMessage.trim() };
    socketRef.current?.emit('sendMessage', msgData);
    setNewMessage('');
  }, [newMessage, selectedAdmin, user]);

  if (loadingAdmins) return <Loading />;

  if (!selectedAdmin) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-blue-400">Chat Admin</h1>
        <p className="text-gray-400">Pilih admin untuk memulai percakapan</p>
        {admins.length === 0 ? (
          <p className="text-gray-500 text-center py-8">Tidak ada admin tersedia</p>
        ) : (
          <div className="grid gap-3">
            {admins.map(admin => (
              <button
                key={admin._id}
                onClick={() => setSelectedAdmin(admin)}
                className="glass p-4 rounded-xl text-left hover:bg-blue-500/20 transition-all border border-blue-500/20 hover:border-blue-400/50 flex items-center gap-4"
              >
                <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center font-bold text-lg">
                  {admin.username[0].toUpperCase()}
                </div>
                <div>
                  <p className="font-semibold">{admin.username}</p>
                  <p className="text-xs text-blue-400 capitalize">{admin.role}</p>
                </div>
                <span className="ml-auto text-blue-400 text-xl">→</span>
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[82vh]">
      {/* Header */}
      <div className="flex justify-between items-center mb-4 glass p-3 rounded-xl border border-blue-500/30">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-blue-600 flex items-center justify-center font-bold">
            {selectedAdmin.username[0].toUpperCase()}
          </div>
          <div>
            <p className="font-semibold">{selectedAdmin.username}</p>
            <p className="text-xs text-blue-400 capitalize">{selectedAdmin.role}</p>
          </div>
        </div>
        <button onClick={() => { setSelectedAdmin(null); setMessages([]); }} className="text-blue-400 hover:text-blue-300 text-sm">
          ← Ganti Admin
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto glass p-4 rounded-xl space-y-2 mb-4">
        {messages.length === 0 && (
          <p className="text-center text-gray-500 mt-10">Belum ada pesan. Mulai percakapan!</p>
        )}
        {messages.map((msg, i) => {
          const isMe = msg.sender === user.id || msg.sender?._id === user.id;
          return (
            <div key={msg._id || i} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-xs lg:max-w-md p-3 rounded-2xl ${isMe ? 'bg-blue-600 rounded-br-sm' : 'bg-gray-800 rounded-bl-sm'}`}>
                {msg.message && <p className="text-sm leading-relaxed">{msg.message}</p>}
                {msg.fileUrl && (
                  msg.fileType === 'video'
                    ? <video src={msg.fileUrl} controls className="mt-2 rounded max-h-48 w-full" />
                    : <img src={msg.fileUrl} alt="file" className="mt-2 rounded max-h-48 object-cover" />
                )}
                <p className="text-xs opacity-50 mt-1 text-right">
                  {new Date(msg.createdAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="flex gap-2">
        <input
          type="text"
          value={newMessage}
          onChange={e => setNewMessage(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && sendMessage()}
          className="flex-1 p-3 bg-black/50 border border-blue-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-400"
          placeholder="Tulis pesan..."
        />
        <button
          onClick={sendMessage}
          disabled={!newMessage.trim()}
          className="bg-blue-600 hover:bg-blue-500 disabled:opacity-40 px-5 rounded-xl font-semibold transition-all"
        >
          Kirim
        </button>
      </div>
    </div>
  );
}
